SD-041_project

# João Figueiredo, nº 53524

# Manuel Tovar, nº 49522

# Mariana Bento, nº 53676

Para correr chamar o 'make'.
Para compilar o ficheiro sdmessage.proto chamar o "make protoc".


OBSERVAÇÕES:
-> Não conseguimos terminar os ficheiros relativos ao cliente nem ao servidor.
-> No entanto, conseguimos melhorar o nosso data.c (que agora passa em todos os testes com sucesso) e no tree.c também fizemos algumas melhorias.
