SD-041_project

# João Figueiredo, nº 53524

# Manuel Tovar, nº 49522

# Mariana Bento, nº 53676

Para correr chamar o 'make'
Para testar o data.c chamar 'make test_data.c'
Para testar o entry.c chamar 'make test_entry.c'
Para testar o tree.c chamar 'make test_tree.c'
Para testar o serialization.c chamar 'make test_serialization.c'

OBSERVAÇÕES:
-> Não conseguimos fazer todas as funções, o que faz com que apenas alguns testes consigam passar.
